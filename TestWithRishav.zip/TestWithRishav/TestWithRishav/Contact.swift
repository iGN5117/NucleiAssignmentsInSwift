//
//  Contact.swift
//  TestWithRishav
//
//  Created by Nilesh Gajwani on 21/01/20.
//  Copyright © 2020 Nilesh Gajwani. All rights reserved.
//

import Foundation
class Contact: Comparable{
    static func < (lhs: Contact, rhs: Contact) -> Bool {
        
        return lhs.getName() < rhs.getName()
    }
    
    static func == (lhs: Contact, rhs: Contact) -> Bool {
        return lhs === rhs
    }
    
    var name: String
    var numbers: [String : String]
    var dates: [String : String]
    var emails: [String : String]
    var notes: String
    
    
    
    init(name: String, numbers: [String: String]) {
        self.name = name
        self.numbers = numbers
        dates = [:]
        emails = [:]
        notes = ""
    }
    
    convenience init() {
        self.init(name: "TestContact", numbers: ["Mobile": "1234567890"])
    }
    
    convenience init(name: String) {
        self.init(name: name, numbers: ["Mobile": "1234567890"])
    }
    
    func getName() -> String {
        return self.name
    }
    
    func getNumber() -> String {
        if let mobileIsAdded = numbers["Mobile"] {
            return mobileIsAdded
        }
        else {
            return numbers[numbers.keys.first ?? ""] ?? "12DontComeHere3"
        }
    }
}
