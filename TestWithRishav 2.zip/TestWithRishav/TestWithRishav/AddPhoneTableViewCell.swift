//
//  AddPhoneTableViewCell.swift
//  TestWithRishav
//
//  Created by Nilesh Gajwani on 21/01/20.
//  Copyright © 2020 Nilesh Gajwani. All rights reserved.
//

import UIKit

protocol PhoneButtonClickedProtocol {
    func buttonTapped(index: IndexPath)
}

class AddPhoneTableViewCell: UITableViewCell {
    @IBOutlet weak var showTypesOfPhoneButton: UIButton!
    
    var index: IndexPath?
    var phoneTappedDelegate: PhoneButtonClickedProtocol?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    @IBAction func phoneButtonClicked(_ sender: Any) {
        if let index = index {
            phoneTappedDelegate?.buttonTapped(index: index)
        }
    }
    
}
