//
//  AddContactViewController.swift
//  TestWithRishav
//
//  Created by Nilesh Gajwani on 21/01/20.
//  Copyright © 2020 Nilesh Gajwani. All rights reserved.
//

import UIKit
//struct contactInfo {
//    var sections: [String] = ["","","",""]
//    var rowData: [:]
//}
class AddContactViewController: UIViewController, UITextFieldDelegate, PhoneButtonClickedProtocol {
    
    
    @IBOutlet weak var addPhoneTableView: UITableView!
    let cellID = "Cell"
    var count = 1
    var buttonText: [Int: String] = [:]
    let addPhoneButton =
        UIButton(type: .contactAdd)
    var cellToAdd: AddPhoneTableViewCell?
    // @IBOutlet var addPhoneText: UITextField?
    var flag = true
    var indexClicked: IndexPath?
    
    override func viewDidLoad(){
        super.viewDidLoad()
        addPhoneTableView.delegate = self
        addPhoneTableView.dataSource = self
        // Do any additional setup after loading the view.
        addPhoneButton.addTarget(self, action: #selector(addPhone), for: .touchUpInside)
        addPhoneTableView.register(UINib(nibName: "AddPhoneTableViewCell", bundle: nil), forCellReuseIdentifier: "addPhone")
        addPhoneTableView.register(UINib(nibName: "ContactInfoTableViewCell", bundle: nil), forCellReuseIdentifier: "addContactInfo")
        addPhoneTableView.register(UINib(nibName: "NotesTableViewCell", bundle: nil), forCellReuseIdentifier: "addNotes")
//        addPhoneTableView.register(UITableViewCell.self, forCellReuseIdentifier: cellID)
//        addPhoneTableView.register(UITableViewCell.self, forCellReuseIdentifier: "celllliddd")
//
        
        self.navigationItem.title = "Add"
        addPhoneTableView.separatorStyle = .none
        self.addPhoneTableView.rowHeight = 44;
    }
    
    func setUpTableView() {
        
    }
    
    
    func changeButtonText(_ toChange: String) {
        print(toChange)
        if let indexClicked = indexClicked, let cell = addPhoneTableView.cellForRow(at: indexClicked) as? AddPhoneTableViewCell {
            cell.showTypesOfPhoneButton.setTitle(toChange + "  >", for: .normal)
        }
        
    }
    
    func buttonTapped(index: IndexPath) {
        indexClicked = index
        let typesOfPhoneView = storyboard?.instantiateViewController(identifier: "ShowTypesOfPhoneViewController") as! ShowTypesOfPhoneViewController
        typesOfPhoneView.addPhoneViewDelegate = self
        self.present(typesOfPhoneView, animated: true, completion: nil)
    }
    
    
    @IBAction func addPhone(_ sender: Any) {
        print("outside if")
        flag = false
        count += 1
        addPhoneTableView.bounds.size.height += 44
        addPhoneTableView.reloadData()
    }
    
    
}

//Table
extension AddContactViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        switch section {
        case 0:
            return 3
        case 1:
            return count
        case 2:
            return count
        case 3:
            return count
        case 4:
            return 1
        default:
            return 0
        }
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if indexPath.row != 0 {
            if editingStyle == .delete {
                count -= 1
                tableView.deleteRows(at: [indexPath], with: .fade)
            }
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let ContactsCellToAdd = addPhoneTableView.dequeueReusableCell(withIdentifier: "addContactInfo", for: indexPath) as! ContactInfoTableViewCell
            if indexPath.row == 0 {
                ContactsCellToAdd.contactInfoTextField.placeholder = "First Name"
            }
            else if indexPath.row == 1 {
                ContactsCellToAdd.contactInfoTextField.placeholder = "Last Name"
            }
            else {
                ContactsCellToAdd.contactInfoTextField.placeholder = "Company"
            }
            return ContactsCellToAdd
        }
        
        if indexPath.section == 1 {
            if indexPath.row == 0 {
                var addPhoneTableViewCell = addPhoneTableView.dequeueReusableCell(withIdentifier: self.cellID)
                if addPhoneTableViewCell == nil {
                    addPhoneTableViewCell = UITableViewCell(style: .default, reuseIdentifier: self.cellID)
                    addPhoneButton.tag = 12
                    addPhoneButton.sizeToFit()
                    addPhoneTableViewCell?.accessoryView = addPhoneButton
                    addPhoneTableViewCell?.textLabel?.text = "Add Phone"
                }
                return addPhoneTableViewCell ?? UITableViewCell()
            } else {
                cellToAdd = addPhoneTableView.dequeueReusableCell(withIdentifier: "addPhone", for: indexPath) as? AddPhoneTableViewCell
                if let textToChange = buttonText[indexPath.row] {
                    print("Setting text!")
                    cellToAdd?.showTypesOfPhoneButton.titleLabel?.text = textToChange
                }
                cellToAdd?.phoneTappedDelegate = self
                cellToAdd?.index = indexPath
                //addPhoneTableView.bounds.size.height += (cellToAdd!.bounds.size.height)
                return cellToAdd!
            }
        }
            
        else if indexPath.section == 2 {
            if indexPath.row == 0 {
                var addPhoneTableViewCell = addPhoneTableView.dequeueReusableCell(withIdentifier: self.cellID)
                if addPhoneTableViewCell == nil {
                    addPhoneTableViewCell = UITableViewCell(style: .default, reuseIdentifier: self.cellID)
                    addPhoneButton.tag = 12
                    addPhoneButton.sizeToFit()
                    let plusButton = UIButton.init(type: .contactAdd)
                    addPhoneTableViewCell?.accessoryView = plusButton
                    addPhoneTableViewCell?.textLabel?.text = "Add Email"
                }
                return addPhoneTableViewCell ?? UITableViewCell()
            } else {
                cellToAdd = addPhoneTableView.dequeueReusableCell(withIdentifier: "addPhone", for: indexPath) as? AddPhoneTableViewCell
                if let textToChange = buttonText[indexPath.row] {
                    print("Setting text!")
                    cellToAdd?.showTypesOfPhoneButton.titleLabel?.text = textToChange
                }
                cellToAdd?.phoneTappedDelegate = self
                cellToAdd?.index = indexPath
                //addPhoneTableView.bounds.size.height += (cellToAdd!.bounds.size.height)
                return cellToAdd!
            }
        }
                    else if indexPath.section == 3 {
                        if indexPath.row == 0 {
                            var addPhoneTableViewCell = addPhoneTableView.dequeueReusableCell(withIdentifier: self.cellID)
                            if addPhoneTableViewCell == nil {
                                addPhoneTableViewCell = UITableViewCell(style: .default, reuseIdentifier: self.cellID)
                                addPhoneButton.tag = 12
                                addPhoneButton.sizeToFit()
                                addPhoneTableViewCell?.accessoryView = UIButton(type: .contactAdd)
                                addPhoneTableViewCell?.textLabel!.text = "Add Date"
            
                            }
                            return addPhoneTableViewCell!
                        }else {
                            cellToAdd = addPhoneTableView.dequeueReusableCell(withIdentifier: "addPhone", for: indexPath) as? AddPhoneTableViewCell
                            if let textToChange = buttonText[indexPath.row] {
                                print("Setting text!")
                                cellToAdd?.showTypesOfPhoneButton.titleLabel?.text = textToChange
                            }
                            cellToAdd?.phoneTappedDelegate = self
                            cellToAdd?.index = indexPath
                            //addPhoneTableView.bounds.size.height += (cellToAdd!.bounds.size.height)
                            return cellToAdd!
                        }
                    }
                    else if indexPath.section == 4 {
                        let NotesCellToAdd = addPhoneTableView.dequeueReusableCell(withIdentifier: "addNotes", for: indexPath) as! NotesTableViewCell
                        return NotesCellToAdd
                    }
        else {
            return UITableViewCell()
        }
    }
}
